public class ObjectPractice02 {
    public static void main(String[] args) {
        Circle circle2 = new Circle(10);
        double a = circle2.getArea();
        double b = circle2.getCircumference();
        System.out.println(a);
        System.out.println(b);
    }
}
