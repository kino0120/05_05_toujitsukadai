public class ObjectPractice01 {
    public static void main(String[] args) {
        Circle circle = new Circle();
        double a = circle.getArea();
        double b = circle.getCircumference();
        System.out.println(a);
        System.out.println(b);
    }
}
