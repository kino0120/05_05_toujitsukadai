public class ObjectPractice04 {
    public static void main(String[] args) {
        Person person4 =new Person("木下","東京都");
        person4.getSelfIntroduction();
    }
}
