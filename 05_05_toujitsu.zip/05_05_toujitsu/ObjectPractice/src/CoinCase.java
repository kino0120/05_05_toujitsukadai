import java.util.Scanner;

public class CoinCase {
    public String money;
    public String amount;

   public CoinCase(String money,String amount){
        this.money = money;
        this.amount = amount;
    }


    public void AddCoins(){
       
    }
//    public void input(){
//        System.out.println("硬貨の種類を入力してください。");
//        Scanner s1 = new Scanner(System.in);
//        this.money = s1.nextLine();
//        System.out.println("硬貨の枚数を入力してください。");
//        Scanner s2 = new Scanner(System.in);
//        this.amount = s2.nextLine();
//    }

}
