import java.util.Scanner;

public class ObjectPractice06 {
    public static void main(String[] args) {
        CoinCase coincases[] = new CoinCase[6];

        for (int i = 0; i < 6; i++) {
            System.out.println("硬貨の種類を入力してください。");
            Scanner s1 = new Scanner(System.in);
            String m = s1.nextLine();
            System.out.println("硬貨の枚数を入力してください。");
            Scanner s2 = new Scanner(System.in);
            String a = s2.nextLine();
            coincases[i] = new CoinCase(m, a);
            coincases[i].AddCoins();
        }
        for (int j = 0; j < 6; j++) {
            System.out.println(coincases[j]);
        }
    }
}

