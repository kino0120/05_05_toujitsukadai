public class ObjectPractice03 {
    public static void main(String[] args) {
        Circle circle3 = new Circle(20);
        System.out.println(circle3.getArea());
        System.out.println(circle3.getCircumference());
    }
}
